"""
Comprehensive Automated Test Suite: Inbound WhatsApp Image Webhook Remediation (V12)
Validates:
1. Processing of multiple messages in a single webhook payload (not just messages[0]).
2. Inbound message lifecycle states (RECEIVED, PROCESSING, COMPLETED, FAILED, RETRY_PENDING).
3. Safe idempotency and duplicate prevention without duplicate replies.
4. Truthful fallback acknowledgements on media download failure and AI failure.
5. Permanent CRM linking of customer photo, inquiry ID, and phone.
6. Separation of catalog reference stock from warehouse physical verification (no false godown claims).
7. Proper ACCEPTED status logging for outbound Meta messages with WAMID.
8. Human takeover handling with photo preservation.
"""

import unittest
import asyncio
import base64
import json
import os
import sqlite3
from unittest.mock import patch, MagicMock

import db
import webhook_bot

class TestImageWebhookRemediation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()

    def setUp(self):
        # Clean test tables for test isolation
        with db.get_db_connection() as conn:
            conn.execute("DELETE FROM inbound_message_lifecycle WHERE msg_id LIKE 'TEST_%'")
            conn.execute("DELETE FROM processed_messages WHERE msg_id LIKE 'TEST_%'")
            conn.execute("DELETE FROM live_inquiries WHERE id LIKE 'TEST_%' OR phone LIKE '9199999999%'")
            conn.execute("DELETE FROM outbound_delivery_logs WHERE phone LIKE '9199999999%'")
            conn.execute("DELETE FROM buyer_sessions WHERE phone LIKE '9199999999%'")

    def tearDown(self):
        with db.get_db_connection() as conn:
            conn.execute("DELETE FROM inbound_message_lifecycle WHERE msg_id LIKE 'TEST_%'")
            conn.execute("DELETE FROM processed_messages WHERE msg_id LIKE 'TEST_%'")
            conn.execute("DELETE FROM live_inquiries WHERE id LIKE 'TEST_%' OR phone LIKE '9199999999%'")
            conn.execute("DELETE FROM outbound_delivery_logs WHERE phone LIKE '9199999999%'")
            conn.execute("DELETE FROM buyer_sessions WHERE phone LIKE '9199999999%'")

    def test_01_inbound_lifecycle_transitions(self):
        """Verify atomic transitions: RECEIVED/PROCESSING -> COMPLETED, and deduplication check."""
        msg_id = "TEST_LIFECYCLE_001"
        phone = "919999999901"

        # 1. First arrival registers as PROCESSING
        res1 = db.record_inbound_message_lifecycle(msg_id, phone, "text")
        self.assertTrue(res1["should_process"])
        self.assertEqual(res1["status"], "PROCESSING")
        self.assertEqual(res1["attempt_count"], 1)

        # 2. While PROCESSING, duplicate attempt must not re-process
        res2 = db.record_inbound_message_lifecycle(msg_id, phone, "text")
        self.assertFalse(res2["should_process"])
        self.assertEqual(res2["status"], "PROCESSING")

        # 3. Complete the message
        db.update_inbound_message_status(msg_id, "COMPLETED")
        status_info = db.get_inbound_message_status(msg_id)
        self.assertEqual(status_info["status"], "COMPLETED")

        # 4. Once COMPLETED, is_message_processed must return True
        self.assertTrue(db.is_message_processed(msg_id, phone))

        # 5. Further duplicate delivery must be rejected
        res3 = db.record_inbound_message_lifecycle(msg_id, phone, "text")
        self.assertFalse(res3["should_process"])
        self.assertEqual(res3["status"], "COMPLETED")

    def test_02_retry_pending_lifecycle(self):
        """Verify that RETRY_PENDING status allows safe retry with incremented attempt_count."""
        msg_id = "TEST_RETRY_001"
        phone = "919999999902"

        db.record_inbound_message_lifecycle(msg_id, phone, "image")
        db.update_inbound_message_status(msg_id, "RETRY_PENDING", "Transient network timeout")

        status_info = db.get_inbound_message_status(msg_id)
        self.assertEqual(status_info["status"], "RETRY_PENDING")
        self.assertEqual(status_info["attempt_count"], 1)

        # Retry arrives
        res = db.record_inbound_message_lifecycle(msg_id, phone, "image")
        self.assertTrue(res["should_process"])
        self.assertEqual(res["status"], "PROCESSING")
        self.assertEqual(res["attempt_count"], 2)

    def test_03_multiple_messages_in_single_webhook_payload(self):
        """Verify that batch payloads with multiple messages process ALL messages, not just messages[0]."""
        payload_val = {
            "contacts": [{"profile": {"name": "Test Multi Buyer"}, "wa_id": "919999999903"}],
            "messages": [
                {"id": "TEST_MULTI_MSG_1", "from": "919999999903", "type": "text", "text": {"body": "Namaste"}},
                {"id": "TEST_MULTI_MSG_2", "from": "919999999903", "type": "text", "text": {"body": "Rate list"}}
            ]
        }

        sent_messages = []
        def mock_send(to, msg, name="Customer"):
            sent_messages.append({"to": to, "msg": msg})
            return {"success": True, "data": {"messages": [{"id": f"wamid_{len(sent_messages)}"}]}}

        with patch("webhook_bot.send_whatsapp_text", side_effect=mock_send):
            asyncio.run(webhook_bot.process_incoming_whatsapp_message(payload_val))

        # Both messages must have lifecycle records and both must be COMPLETED
        st1 = db.get_inbound_message_status("TEST_MULTI_MSG_1")
        st2 = db.get_inbound_message_status("TEST_MULTI_MSG_2")
        self.assertEqual(st1["status"], "COMPLETED")
        self.assertEqual(st2["status"], "COMPLETED")
        self.assertGreaterEqual(len(sent_messages), 2)

    def test_04_image_download_failure_fallback_and_crm_linking(self):
        """Verify that media download failure triggers truthful fallback and flags CRM inquiry."""
        msg_id = "TEST_IMG_DOWNLOAD_FAIL"
        phone = "919999999904"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_nonexistent_999", "caption": "Urgent matching needed"}
        }

        sent_texts = []
        def mock_send(to, text, name="Customer"):
            sent_texts.append(text)
            return {"success": True, "data": {"messages": [{"id": "wamid_fallback_1"}]}}

        with patch("webhook_bot.download_whatsapp_media", side_effect=Exception("Meta 404 Media Not Found")), \
             patch("webhook_bot.send_whatsapp_text", side_effect=mock_send):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Kapil Garments"}}]))

        # Lifecycle must be FAILED with error message
        st = db.get_inbound_message_status(msg_id)
        self.assertEqual(st["status"], "FAILED")
        self.assertIn("Media download failed", st["error_message"])

        # Truthful fallback sent to customer
        self.assertTrue(len(sent_texts) > 0)
        self.assertIn("network connectivity ke kaaran image download verify nahi ho paayi", sent_texts[0])

        # CRM inquiry flagged for human review
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            inq = cur.fetchone()
            self.assertIsNotNone(inq)
            self.assertIn("Image Download Failed - Needs Human Review", inq["status"])

    def test_05_image_ai_failure_fallback(self):
        """Verify that AI engine failure triggers truthful fallback acknowledgement and flags CRM."""
        msg_id = "TEST_IMG_AI_FAIL"
        phone = "919999999905"
        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_valid_123", "caption": "Trocas 4 hole"}
        }

        sent_texts = []
        def mock_send(to, text, name="Customer"):
            sent_texts.append(text)
            return {"success": True, "data": {"messages": [{"id": "wamid_ai_fallback_1"}]}}

        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.analyze_button_or_fabric_image", side_effect=Exception("Gemini quota exhausted")), \
             patch("webhook_bot.send_whatsapp_text", side_effect=mock_send):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Textile Corp"}}]))

        st = db.get_inbound_message_status(msg_id)
        self.assertEqual(st["status"], "FAILED")
        self.assertIn("AI Analysis failed", st["error_message"])

        self.assertTrue(len(sent_texts) > 0)
        self.assertIn("Image analysis verify ki jaa rahi hai", sent_texts[0])

        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            inq = cur.fetchone()
            self.assertIsNotNone(inq)
            self.assertIn("AI Analysis Review Required", inq["status"])
            self.assertTrue(len(inq["photo_b64"]) > 0)

    def test_06_exact_match_stock_disclaimer_truthfulness(self):
        """Verify that incoming customer photo sends ZERO automatic catalog photos, and only verified sales action dispatches photo."""
        msg_id = "TEST_IMG_EXACT_MATCH"
        phone = "919999999906"
        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_mop_001", "caption": "MOP button 18L"}
        }

        sent_captions = []
        sent_texts = []
        def mock_send_img(to, img_bytes, caption, sku="", product_name="", size_opts="", buyer_name=""):
            sent_captions.append(caption)
            return {"success": True, "data": {"messages": [{"id": "wamid_img_exact"}]}}

        mock_ai_result = {
            "match_status": "MATCH_FOUND",
            "best_match_sku": "ABC-136",
            "is_button": True,
            "match_confidence": 94
        }

        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.analyze_button_or_fabric_image", return_value=mock_ai_result), \
             patch("webhook_bot.send_whatsapp_image", side_effect=mock_send_img), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Sharma Exports"}}]))

        st = db.get_inbound_message_status(msg_id)
        self.assertEqual(st["status"], "COMPLETED")

        # Business Rule: ZERO auto-sent catalog photos on customer photo
        self.assertEqual(len(sent_captions), 0, "Bot must NOT automatically send catalog photos")
        self.assertTrue(len(sent_texts) > 0)
        self.assertIn("Inquiry ID: INQ-", sent_texts[0])

        # When authorized salesperson executes Action 1 (Stock Check & Send Verified Photo)
        with patch("webhook_bot.send_whatsapp_image", side_effect=mock_send_img):
            webhook_bot.send_verified_stock_and_photo(phone, "ABC-136", warehouse_stock=1250, salesperson_name="Amit")

        self.assertTrue(len(sent_captions) > 0)
        caption = sent_captions[0]
        # Must clearly state physical warehouse verification requirement
        self.assertIn("1,250 Gross", caption)
        self.assertIn("physically verified", caption.lower())

    def test_07_human_takeover_photo_preservation_without_auto_reply(self):
        """Verify that under human takeover, photos are preserved in CRM with zero bot auto-replies."""
        phone = "919999999907"
        msg_id = "TEST_TAKEOVER_PHOTO"

        # Activate human takeover in session
        db.save_session_db(phone, {"human_takeover": 1, "contact_name": "Takeover Buyer"})

        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_takeover_1", "caption": "Operator please see"}
        }

        sent_texts = []
        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Takeover Buyer"}}]))

        # Zero auto replies sent to customer
        self.assertEqual(len(sent_texts), 0)

        # Inbound lifecycle must be COMPLETED
        st = db.get_inbound_message_status(msg_id)
        self.assertEqual(st["status"], "COMPLETED")

        # Photo permanently stored in CRM
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT photo_b64, status FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            inq = cur.fetchone()
            self.assertIsNotNone(inq)
            self.assertTrue(len(inq["photo_b64"]) > 0)
            self.assertEqual(inq["status"], "Human Takeover Active")

    def test_08_outbound_status_is_accepted_not_premature_sent(self):
        """Verify that outbound delivery logs record ACCEPTED upon Meta 200 acceptance with WAMID."""
        phone = "919999999908"
        fake_wamid = "wamid.TEST_OUTBOUND_ACCEPTED_001"

        with patch("webhook_bot._raw_send_whatsapp_text", return_value={"success": True, "data": {"messages": [{"id": fake_wamid}]}}):
            res = webhook_bot.send_whatsapp_text(phone, "Test status text message")
            self.assertTrue(res.get("success"))

        status_rec = db.get_message_delivery_status(fake_wamid)
        self.assertEqual(status_rec.get("status"), "ACCEPTED")

if __name__ == "__main__":
    unittest.main()
