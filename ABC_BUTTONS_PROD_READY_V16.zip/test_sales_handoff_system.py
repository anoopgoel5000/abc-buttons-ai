"""
Comprehensive Test Suite: ABC Buttons 24x7 WhatsApp AI Sales Handoff System
Validates all 17 Business Requirements:
1. Instant acknowledgement on customer button photo.
2. ZERO automatic catalog product photo dispatch.
3. ZERO false claims of exact design availability or ready stock.
4. Conversational collection of missing details (Quantity, Company, City).
5. Reuse existing customer details without repeated questions.
6. Preservation of original WhatsApp photo, buyer notes, required quantity.
7. Unique internal Inquiry ID (INQ-YYYYMMDD-XXXX).
8. Persistent save before claiming forwarded.
9. Transfer to Sales Team queue with all details.
10. Sales Team Actions: Stock Check, Similar Samples, Factory Feasibility, Quotation.
11. Authorized sales team confirmation only.
12. Human Takeover support (AI pauses completely).
13. Truthful after-hours acknowledgement.
14. Follow-up tracking and status updates.
15. Cross-server sync between Streamlit and Render.
16. Preservation of existing catalog and calculation features.
17. Automated tests for photo-only, after-hours, repeat buyers, missing details, human handoff.
"""

import unittest
import asyncio
import datetime
import json
import os
import sqlite3
from unittest.mock import patch, MagicMock

import db
import webhook_bot

class TestSalesHandoffSystem(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db.init_db()

    def setUp(self):
        # Clean test records
        with db.get_db_connection() as conn:
            conn.execute("DELETE FROM inbound_message_lifecycle WHERE msg_id LIKE 'TEST_HANDOFF_%'")
            conn.execute("DELETE FROM processed_messages WHERE msg_id LIKE 'TEST_HANDOFF_%'")
            conn.execute("DELETE FROM live_inquiries WHERE id LIKE 'INQ-%' OR phone LIKE '9198888888%'")
            conn.execute("DELETE FROM outbound_delivery_logs WHERE phone LIKE '9198888888%'")
            conn.execute("DELETE FROM buyer_sessions WHERE phone LIKE '9198888888%'")

    def tearDown(self):
        with db.get_db_connection() as conn:
            conn.execute("DELETE FROM inbound_message_lifecycle WHERE msg_id LIKE 'TEST_HANDOFF_%'")
            conn.execute("DELETE FROM processed_messages WHERE msg_id LIKE 'TEST_HANDOFF_%'")
            conn.execute("DELETE FROM live_inquiries WHERE id LIKE 'INQ-%' OR phone LIKE '9198888888%'")
            conn.execute("DELETE FROM outbound_delivery_logs WHERE phone LIKE '9198888888%'")
            conn.execute("DELETE FROM buyer_sessions WHERE phone LIKE '9198888888%'")

    def test_01_photo_only_message_intake_and_zero_catalog_images(self):
        """Req 1, 2, 3, 4, 7, 8: Buyer sends photo only -> gets polite acknowledgment with Inquiry ID, NO catalog photo."""
        phone = "919888888801"
        msg_id = "TEST_HANDOFF_001"
        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_btn_photo_01", "caption": ""}
        }

        sent_texts = []
        sent_images = []

        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)), \
             patch("webhook_bot.send_whatsapp_image", side_effect=lambda to, b, c, **kw: sent_images.append(c)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Sunil Sharma"}}]))

        # Rule 2: ZERO automatic catalog images sent!
        self.assertEqual(len(sent_images), 0, "Bot must NEVER auto-send catalog images on customer photo")

        # Rule 1 & 7: Exactly 1 polite text acknowledgment with Inquiry ID
        self.assertTrue(len(sent_texts) > 0)
        reply = sent_texts[0]
        self.assertIn("Inquiry ID: INQ-", reply)
        self.assertIn("Sunil", reply)

        # Rule 4: Asks for quantity in Gross
        self.assertIn("quantity", reply.lower())
        self.assertIn("gross", reply.lower())

        # Rule 8: Persistently saved in database
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT * FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            inq = cur.fetchone()
            self.assertIsNotNone(inq)
            self.assertTrue(inq["id"].startswith("INQ-"))
            self.assertTrue(len(inq["photo_b64"]) > 0)
            self.assertEqual(inq["buyer_name"], "Sunil Sharma")
            self.assertIn("New Inquiry", inq["status"])

    def test_02_after_hours_inquiry_acknowledgement(self):
        """Req 13: Inquiries received outside office hours acknowledge gracefully without false time commitments."""
        phone = "919888888802"
        msg_id = "TEST_HANDOFF_002"
        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": msg_id,
            "from": phone,
            "type": "image",
            "image": {"id": "media_btn_photo_02", "caption": "late night check"}
        }

        sent_texts = []
        # Mock IST time to 11:30 PM (outside 9:30 AM - 7:00 PM)
        late_night_utc = datetime.datetime(2026, 11, 17, 18, 0, 0, tzinfo=datetime.timezone.utc) # 23:30 IST

        with patch("datetime.datetime") as mock_dt:
            mock_dt.now.return_value = late_night_utc
            mock_dt.timedelta = datetime.timedelta
            mock_dt.timezone = datetime.timezone
            mock_dt.time = datetime.time

            with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
                 patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)), \
                 patch("webhook_bot.send_whatsapp_image", side_effect=lambda *a, **k: None):
                asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Vikas"}}]))

        self.assertTrue(len(sent_texts) > 0)
        reply = sent_texts[0]
        self.assertIn("office closed", reply.lower())
        self.assertIn("Inquiry ID: INQ-", reply)

    def test_03_conversational_missing_details_qualification(self):
        """Req 4: Conversation flow: Photo -> ask quantity -> reply 300 gross -> ask company/city -> reply Apex Surat -> confirmed."""
        phone = "919888888803"

        # Step 1: Customer sends photo
        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg1 = {
            "id": "TEST_HANDOFF_003_A",
            "from": phone,
            "type": "image",
            "image": {"id": "media_btn_003", "caption": ""}
        }

        sent1 = []
        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent1.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg1, [{"profile": {"name": "Pawan"}}]))

        self.assertTrue(len(sent1) > 0)
        self.assertIn("quantity", sent1[0].lower())

        # Step 2: Customer replies with quantity: "300 gross"
        msg2 = {
            "id": "TEST_HANDOFF_003_B",
            "from": phone,
            "type": "text",
            "text": {"body": "300 gross chahiye"}
        }
        sent2 = []
        with patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent2.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg2, [{"profile": {"name": "Pawan"}}]))

        self.assertTrue(len(sent2) > 0)
        # Should record 300 gross and ask for company & city
        self.assertIn("300", sent2[0])
        self.assertIn("company", sent2[0].lower())

        # Verify DB updated quantity
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT quantity FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            row = cur.fetchone()
            self.assertEqual(row["quantity"], 300)

        # Step 3: Customer replies with Company and City: "Apex Fashions, Surat"
        msg3 = {
            "id": "TEST_HANDOFF_003_C",
            "from": phone,
            "type": "text",
            "text": {"body": "Apex Fashions, Surat"}
        }
        sent3 = []
        with patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent3.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg3, [{"profile": {"name": "Pawan"}}]))

        self.assertTrue(len(sent3) > 0)
        self.assertIn("Apex Fashions", sent3[0])
        self.assertIn("Surat", sent3[0])

        # Verify DB updated company and city
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT company, city, quantity FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            row = cur.fetchone()
            self.assertEqual(row["company"], "Apex Fashions")
            self.assertEqual(row["city"], "Surat")
            self.assertEqual(row["quantity"], 300)

    def test_04_repeat_buyer_reuses_existing_details(self):
        """Req 5: Repeat buyer already has company & city on record; bot does not ask again."""
        phone = "919888888804"

        # Pre-populate database with existing buyer details
        db.save_inquiry_with_photo(
            inquiry_id="INQ-20261117-0099",
            phone=phone,
            buyer_name="Rajesh Goyal",
            photo_b64="",
            notes="Existing client",
            company="Goyal Garments",
            city="Ludhiana",
            quantity=500
        )

        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": "TEST_HANDOFF_004",
            "from": phone,
            "type": "image",
            "image": {"id": "media_btn_photo_04", "caption": "500 gross same chahiye"}
        }

        sent_texts = []
        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "Rajesh Goyal"}}]))

        self.assertTrue(len(sent_texts) > 0)
        reply = sent_texts[0]
        # Should NOT ask for company/city because it is already known
        self.assertNotIn("kripya apni company", reply.lower())
        self.assertIn("Goyal Garments", reply)
        self.assertIn("Ludhiana", reply)

    def test_05_human_takeover_halts_ai_completely(self):
        """Req 12: When human takeover is active, AI auto-replies are paused and customer photos are preserved."""
        phone = "919888888805"
        db.save_session_db(phone, {"human_takeover": 1, "contact_name": "VIP Buyer"})

        dummy_jpg = b"\xff\xd8\xff\xe0\x00\x10JFIF\x00\x01\x01\x01\x00`\x00`\x00\x00\xff\xdb\x00C\x00\xff\xd9"
        msg = {
            "id": "TEST_HANDOFF_005",
            "from": phone,
            "type": "image",
            "image": {"id": "media_takeover_05", "caption": "Special order check"}
        }

        sent_texts = []
        with patch("webhook_bot.download_whatsapp_media", return_value=dummy_jpg), \
             patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)):
            asyncio.run(webhook_bot.process_single_whatsapp_message(msg, [{"profile": {"name": "VIP Buyer"}}]))

        # ZERO auto replies under takeover
        self.assertEqual(len(sent_texts), 0)

        # Photo saved in DB
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT photo_b64, status FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            inq = cur.fetchone()
            self.assertIsNotNone(inq)
            self.assertTrue(len(inq["photo_b64"]) > 0)
            self.assertEqual(inq["status"], "Human Takeover Active")

    def test_06_sales_team_action_stock_check_and_verified_photo(self):
        """Req 10, 11: Authorized sales team member sends physically verified catalog photo and stock."""
        phone = "919888888806"
        dispatched_captions = []
        dispatched_skus = []

        def mock_send_img(to, img_bytes, caption, sku="", **kw):
            dispatched_captions.append(caption)
            dispatched_skus.append(sku)
            return {"success": True, "data": {"messages": [{"id": "wamid_v_01"}]}}

        with patch("webhook_bot.send_whatsapp_image", side_effect=mock_send_img):
            res = webhook_bot.send_verified_stock_and_photo(
                phone=phone,
                sku="ABC-136",
                warehouse_stock=1200,
                salesperson_name="Amit Verma",
                custom_note="Ready batch inspected in Godown 2."
            )

        self.assertTrue(len(dispatched_captions) > 0)
        cap = dispatched_captions[0]
        self.assertIn("ABC-136", cap)
        self.assertIn("1,200 Gross", cap)
        self.assertIn("Physically Verified", cap)
        self.assertIn("Amit Verma", cap)

        # Status in DB updated
        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT action_taken, crm_status FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            row = cur.fetchone()
            self.assertIsNotNone(row)
            self.assertIn("Stock Check Verified", row["action_taken"])
            self.assertEqual(row["crm_status"], "Stock Confirmed - Ready to Quote")

    def test_07_sales_team_action_similar_options(self):
        """Req 10: Sales team offers similar options with polite permission pitch."""
        phone = "919888888807"
        sent_texts = []
        sent_images = []

        with patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)), \
             patch("webhook_bot.send_whatsapp_image", side_effect=lambda to, b, c, **kw: sent_images.append(c)):
            webhook_bot.send_similar_options_pitch(phone, ["ABC-136", "ABC-139"], salesperson_name="Pooja")

        self.assertTrue(len(sent_texts) > 0)
        self.assertIn("similar", sent_texts[0].lower())
        self.assertIn("Pooja", sent_texts[0])

        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT action_taken, crm_status FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            row = cur.fetchone()
            self.assertIn("Similar Options Sent", row["action_taken"])

    def test_08_sales_team_action_custom_mfg_feasibility(self):
        """Req 10: Sales team sends custom manufacturing feasibility with MOQ and lead time."""
        phone = "919888888808"
        sent_texts = []

        with patch("webhook_bot.send_whatsapp_text", side_effect=lambda to, t, n="": sent_texts.append(t)):
            webhook_bot.send_custom_mfg_feasibility(phone, moq=500, lead_days=10, salesperson_name="Gaurav")

        self.assertTrue(len(sent_texts) > 0)
        msg = sent_texts[0]
        self.assertIn("Custom Manufacturing Feasibility", msg)
        self.assertIn("500 Gross", msg)
        self.assertIn("10-12 Days", msg)
        self.assertIn("Gaurav", msg)

        with db.get_db_connection() as conn:
            cur = conn.cursor()
            cur.execute("SELECT action_taken, crm_status FROM live_inquiries WHERE phone = ?", (db.normalize_phone(phone),))
            row = cur.fetchone()
            self.assertIn("Factory Feasibility Sent", row["action_taken"])

if __name__ == "__main__":
    unittest.main()
