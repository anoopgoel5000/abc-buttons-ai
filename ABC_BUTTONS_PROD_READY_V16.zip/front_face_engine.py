"""
ABC BUTTONS - FRONT-FACE EXACT DESIGN MATCHING ENGINE
=====================================================
Prioritizes exact front-face button design identification.
Engineering candidate ranking weights:
  - Front design, engraving, raised decorative ring & surface pattern: 35% (0.35)
  - Outer shape and contour: 25% (0.25)
  - Hole count, arrangement, position and spacing: 20% (0.20)
  - Button color and visible color pattern: 10% (0.10)
  - Apparent material: 10% (0.10)

Strict Verification Gates:
  1. Hole-count conflict (e.g. 2-hole vs 4-hole) prevents EXACT MATCH.
  2. Outer shape conflict (e.g. Round vs Oval/Cowrie/Flower) prevents EXACT MATCH.
  3. Design conflict (e.g. Plain flat vs Raised rim vs Engraved vs Shank) prevents EXACT MATCH.
  4. Clear color conflict (e.g. White vs Black/Charcoal, Turquoise vs Pink) prevents EXACT MATCH.
  5. Non-catalog material / non-button detection prevents EXACT MATCH.

Explicitly Excluded Features:
  - Button thickness, physical diameter, ligne sizes (14L/18L/24L) are NOT used for visual matching.
  - Back-side appearance is NOT used for primary front-face matching.

Required Decision Labels:
  - EXACT DESIGN CANDIDATE: All visible mandatory attributes match, subject to physical verification.
  - POSSIBLE MATCH: Some attributes match, but exact identity is uncertain.
  - NEED CLEAR FRONT PHOTO: Critical details are not visible, blurry, or mixed button designs.
  - NO EXACT MATCH: No catalog candidate passes strict verification.
"""

import os
import re
import json
import base64
import html
from typing import Dict, Any, List, Tuple, Optional
from PIL import Image
import io

# Catalog Front-Face Ground Truth Profiles for all 21 ABC Buttons SKUs
CATALOG_FRONT_FACE_PROFILES: Dict[str, Dict[str, Any]] = {
    "ABC-136": {
        "sku": "ABC-136",
        "name": "ABC-136 White Pearl Agoya Shell Button (Bulk Stock)",
        "front_design": "smooth_gloss_rim",
        "outer_shape": "round",
        "holes": [2, 4],
        "hole_pattern": "standard",
        "color_family": "white",
        "color_pattern": "solid_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 175.0,
        "stock_gross": 1250,
        "category": "Shell / MOP",
        "recommended_garment": "Tuxedo Shirts, Collars, High-Volume Formal Shirt Programs",
        "description": "High-volume staple shell button in bright white luster for shirt exporters."
    },
    "ABC-137": {
        "sku": "ABC-137",
        "name": "ABC-137 Caramel Gold MOP Shell Button",
        "front_design": "beveled_saucer_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "gold_amber",
        "color_pattern": "solid_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 340.0,
        "stock_gross": 280,
        "category": "Shell / MOP",
        "recommended_garment": "Beige/Tan Suits, Cashmere Cardigans, Safari Jackets",
        "description": "Rich champagne gold natural shell luster with smooth beveled rim."
    },
    "ABC-138": {
        "sku": "ABC-138",
        "name": "ABC-138 Midnight Black Lip Shell Button",
        "front_design": "smooth_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "black_charcoal",
        "color_pattern": "peacock_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 390.0,
        "stock_gross": 195,
        "category": "Shell / MOP",
        "recommended_garment": "Black Tuxedos, Navy Evening Wear, Luxury Outerwear",
        "description": "Premium dark Tahitian oyster shell with peacock overtone iridescence."
    },
    "ABC-139": {
        "sku": "ABC-139",
        "name": "ABC-139 Natural White River Shell Button (2-Hole Raised Rim)",
        "front_design": "saucer_rim",
        "outer_shape": "round",
        "holes": [2],
        "hole_pattern": "linear_2_hole",
        "color_family": "white",
        "color_pattern": "solid_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 210.0,
        "stock_gross": 850,
        "category": "Shell / MOP",
        "recommended_garment": "Linen Shirts, Kurta Programs, Summer Blouses",
        "description": "Natural white river shell 2-hole button with distinct raised saucer rim border and recessed center."
    },
    "ABC-140": {
        "sku": "ABC-140",
        "name": "ABC-140 Bronze Luster Shell Button",
        "front_design": "raised_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "bronze_brown",
        "color_pattern": "metallic_luster",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 290.0,
        "stock_gross": 310,
        "category": "Shell / MOP",
        "recommended_garment": "Tweed Blazers, Earth-Tone Jackets, Khaki Outerwear",
        "description": "Deep bronze luster with natural sea shell grain and warm highlights."
    },
    "ABC-141": {
        "sku": "ABC-141",
        "name": "ABC-141 Smoky Gunmetal Trocas Shell Button (4-Hole)",
        "front_design": "center_well_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "grey_gunmetal",
        "color_pattern": "smoky_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 320.0,
        "stock_gross": 420,
        "category": "Shell / MOP",
        "recommended_garment": "Charcoal Suits, Slate Grey Shirts, Winter Overcoats",
        "description": "Smoky gunmetal grey iridescent sheen in 4-hole center well design."
    },
    "ABC-142": {
        "sku": "ABC-142",
        "name": "ABC-142 Ocean Turquoise & Teal Dyed MOP Button",
        "front_design": "flat_face",
        "outer_shape": "round",
        "holes": [2],
        "hole_pattern": "linear_2_hole",
        "color_family": "turquoise_teal",
        "color_pattern": "dyed_solid",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 260.0,
        "stock_gross": 180,
        "category": "Shell / MOP",
        "recommended_garment": "Resort Wear, Printed Hawaiian Shirts, Bohemian Kurtis",
        "description": "Vibrant ocean turquoise blue & teal dyed natural mother-of-pearl flat face."
    },
    "ABC-143": {
        "sku": "ABC-143",
        "name": "ABC-143 Natural Spotted River Shell Button (2-Hole)",
        "front_design": "saucer_rim",
        "outer_shape": "round",
        "holes": [2],
        "hole_pattern": "linear_2_hole",
        "color_family": "white_amber",
        "color_pattern": "spotted_freckled",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 225.0,
        "stock_gross": 340,
        "category": "Shell / MOP",
        "recommended_garment": "Handloom Kurtas, Organic Cotton Shirts, Nehru Jackets",
        "description": "Natural river shell with distinct organic brown/amber freckles and spots."
    },
    "ABC-144": {
        "sku": "ABC-144",
        "name": "ABC-144 Pink Blush Cherry Blossom MOP Shell Button (2-Hole)",
        "front_design": "beveled_rim",
        "outer_shape": "round",
        "holes": [2],
        "hole_pattern": "linear_2_hole",
        "color_family": "pink_blush",
        "color_pattern": "solid_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 280.0,
        "stock_gross": 215,
        "category": "Shell / MOP",
        "recommended_garment": "Pastel Women's Wear, Spring Silk Blouses, Designer Kurtis",
        "description": "Soft pink blush cherry blossom luster from rare pink lip river shell."
    },
    "ABC-145": {
        "sku": "ABC-145",
        "name": "ABC-145 Rustic Raw-Texture River Shell Button (4-Hole Chunky)",
        "front_design": "raw_pitted_face",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "white_cream",
        "color_pattern": "rustic_matte",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 310.0,
        "stock_gross": 160,
        "category": "Shell / MOP",
        "recommended_garment": "Raw Silk Kurtas, Chunky Wool Cardigans, Artisanal Jackets",
        "description": "Unpolished rustic river shell face retaining natural raw fissures and organic ridges."
    },
    "ABC-146": {
        "sku": "ABC-146",
        "name": "ABC-146 Champagne Amber Pearl 4-Hole Shirt Button",
        "front_design": "raised_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "gold_amber",
        "color_pattern": "pearl_luster",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 240.0,
        "stock_gross": 520,
        "category": "Shell / MOP",
        "recommended_garment": "Champagne Silk Shirts, Festive Kurtas, Premium Formal Wear",
        "description": "Translucent champagne amber pearl luster with raised rim and 4-hole center."
    },
    "ABC-147": {
        "sku": "ABC-147",
        "name": "ABC-147 Classic White Chalk Pearl 4-Hole Shirt Button",
        "front_design": "raised_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "white",
        "color_pattern": "chalk_matte",
        "apparent_material": "polyester_resin",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 95.0,
        "stock_gross": 2400,
        "category": "Polyester / Resin",
        "recommended_garment": "School Uniforms, High-Volume Formal Shirts, Hospital Scrubs",
        "description": "Durable chalk-finish high-grade polyester button with smooth raised rim."
    },
    "ABC-148": {
        "sku": "ABC-148",
        "name": "ABC-148 Seafoam Green & Teal Swirl Shell Button (4-Hole)",
        "front_design": "center_well_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "green_seafoam",
        "color_pattern": "swirl_marbled",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 310.0,
        "stock_gross": 190,
        "category": "Shell / MOP",
        "recommended_garment": "Sage Green Linen Shirts, Designer Tunics, Summer Outerwear",
        "description": "Natural trocas shell dyed in soft seafoam green with dark teal wavy swirls."
    },
    "ABC-149": {
        "sku": "ABC-149",
        "name": "ABC-149 Violet Lip Swirl MOP Shell Button (4-Hole)",
        "front_design": "center_well_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "purple_violet",
        "color_pattern": "swirl_marbled",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 350.0,
        "stock_gross": 140,
        "category": "Shell / MOP",
        "recommended_garment": "Lavender Shirts, Evening Gowns, Designer Kurtas",
        "description": "Rare natural violet lip shell with deep amethyst swirls and bright pearl highlights."
    },
    "ABC-150": {
        "sku": "ABC-150",
        "name": "ABC-150 Olive Moss Swirl Trocas Shell Button (4-Hole)",
        "front_design": "center_well_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "olive_moss",
        "color_pattern": "swirl_marbled",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 300.0,
        "stock_gross": 230,
        "category": "Shell / MOP",
        "recommended_garment": "Military Style Shirts, Olive Chinos, Khaki Safari Jackets",
        "description": "Earthy olive green and mossy swirl pattern on dense trocas sea shell."
    },
    "ABC-151": {
        "sku": "ABC-151",
        "name": "ABC-151 Smoky Charcoal Black Pearl Shell Button (2-Hole)",
        "front_design": "raised_rim",
        "outer_shape": "round",
        "holes": [2],
        "hole_pattern": "linear_2_hole",
        "color_family": "black_charcoal",
        "color_pattern": "smoky_iridescent",
        "apparent_material": "shell_mop",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 275.0,
        "stock_gross": 360,
        "category": "Shell / MOP",
        "recommended_garment": "Black Linen Shirts, Charcoal Kurtas, Contemporary Outerwear",
        "description": "Natural black lip oyster shell with 2-hole rim and dark smoky iridescence."
    },
    "ABC-152": {
        "sku": "ABC-152",
        "name": "ABC-152 Natural White Sea Cowrie Shell Beads (Kaudi)",
        "front_design": "kaudi_slit",
        "outer_shape": "cowrie_oval",
        "holes": [0, 1],
        "hole_pattern": "natural_slit",
        "color_family": "white_cream",
        "color_pattern": "natural_shell",
        "apparent_material": "sea_cowrie",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": True,
        "rate_per_gross": 180.0,
        "stock_gross": 950,
        "category": "Kaudi / Specialty",
        "recommended_garment": "Boho Dresses, Bridal Lehengas, Dupatta Borders, Chaniya Cholis",
        "description": "Genuine natural white sea cowrie shells with traditional serrated slit for stitching."
    },
    "ABC-153": {
        "sku": "ABC-153",
        "name": "ABC-153 Electroplated Metallic Gold Cowrie Shell Charms",
        "front_design": "kaudi_slit_plated",
        "outer_shape": "cowrie_oval",
        "holes": [0, 1],
        "hole_pattern": "natural_slit",
        "color_family": "gold_amber",
        "color_pattern": "metallic_plated",
        "apparent_material": "electroplated_shell",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": True,
        "rate_per_gross": 420.0,
        "stock_gross": 410,
        "category": "Kaudi / Specialty",
        "recommended_garment": "Festive Sherwanis, Designer Bridal Wear, Latkans, Luxury Trims",
        "description": "Natural sea cowrie shell coated in 24K mirror-finish electroplated metallic gold."
    },
    "ABC-POLY-18L-08": {
        "sku": "ABC-POLY-18L-08",
        "name": "ABC-POLY-18L-08 Chalk Finish Standard Polyester Shirt Button",
        "front_design": "center_well_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "white_ivory",
        "color_pattern": "chalk_matte",
        "apparent_material": "polyester_resin",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 65.0,
        "stock_gross": 3500,
        "category": "Polyester / Resin",
        "recommended_garment": "School Uniforms, Everyday Workwear, High-Speed Garment Lines",
        "description": "Standard chalk finish polyester shirt button with 4-hole center well."
    },
    "ABC-POLY-18L-10": {
        "sku": "ABC-POLY-18L-10",
        "name": "ABC-POLY-18L-10 Pearlized Polyester Faux-MOP Shirt Button",
        "front_design": "raised_rim",
        "outer_shape": "round",
        "holes": [4],
        "hole_pattern": "square_4_hole",
        "color_family": "white_pearl",
        "color_pattern": "pearl_pigment",
        "apparent_material": "polyester_resin",
        "is_engraved": False,
        "is_card": False,
        "is_cowrie": False,
        "rate_per_gross": 85.0,
        "stock_gross": 2800,
        "category": "Polyester / Resin",
        "recommended_garment": "Executive Shirts, Blouses, Budget Formal Wear",
        "description": "Faux mother-of-pearl luster polyester shirt button with smooth raised rim."
    },
    "ABC-SAMPLE-CARD-01": {
        "sku": "ABC-SAMPLE-CARD-01",
        "name": "ABC-SAMPLE-CARD-01 Official Shell Button Sample Hanger Card",
        "front_design": "hanger_card_display",
        "outer_shape": "rectangular_card",
        "holes": [2, 4],
        "hole_pattern": "assorted_grid",
        "color_family": "multi_assorted",
        "color_pattern": "assorted",
        "apparent_material": "card_with_shell_buttons",
        "is_engraved": False,
        "is_card": True,
        "is_cowrie": False,
        "rate_per_gross": 0.0,
        "stock_gross": 50,
        "category": "Sample Sets",
        "recommended_garment": "Buyer Sampling & Showroom Presentation",
        "description": "Official ABC Buttons sample hanger card displaying full range of river shell and MOP buttons."
    }
}


class FrontFaceDesignMatcher:
    """
    Precision Engine for matching front-face button designs against the ABC Buttons catalog.
    Strictly applies engineering weights, verification gates, and returns Top 3 candidates.
    """

    # Weights defined in engineering specification
    WEIGHT_FRONT_DESIGN = 0.35
    WEIGHT_OUTER_SHAPE = 0.25
    WEIGHT_HOLE_GEOMETRY = 0.20
    WEIGHT_COLOR_PATTERN = 0.10
    WEIGHT_APPARENT_MATERIAL = 0.10

    def __init__(self, catalog_profiles: Optional[Dict[str, Dict[str, Any]]] = None):
        self.profiles = catalog_profiles or CATALOG_FRONT_FACE_PROFILES

    # -------------------------------------------------------------------------
    # 1. Feature Extraction (Conservative & Evidence-Based)
    # -------------------------------------------------------------------------
    def extract_features(self, image_bytes: bytes, user_query: str = "") -> Dict[str, Any]:
        """
        Extracts structured front-face features from image bytes and user query text.
        Conservative estimation: separates confirmed visual evidence from visual guesses.
        """
        # Step 1: Query text signals
        q_lower = (user_query or "").lower()

        # Step 2: Extract visual properties via PIL
        im_features = self._analyze_image_pixels(image_bytes, user_query)

        # Merge with query clues if present
        is_button = im_features.get("is_button", True)
        if any(w in q_lower for w in ["bed", "blanket", "pillow", "cloth only", "no button", "plain fabric"]):
            is_button = False

        # Hole count estimation
        holes_detected = im_features.get("holes_detected", "UNKNOWN")
        if "2-hole" in q_lower or "2 hole" in q_lower or "2hole" in q_lower:
            holes_detected = 2
        elif "4-hole" in q_lower or "4 hole" in q_lower or "4hole" in q_lower:
            holes_detected = 4
        elif "kaudi" in q_lower or "cowrie" in q_lower:
            holes_detected = 0

        # Outer shape estimation
        outer_shape = im_features.get("outer_shape", "UNKNOWN")
        if "card" in q_lower or "hanger" in q_lower or "sample card" in q_lower:
            outer_shape = "rectangular_card"
        elif "kaudi" in q_lower or "cowrie" in q_lower:
            outer_shape = "cowrie_oval"
        elif "flower" in q_lower or "star" in q_lower or "heart" in q_lower:
            outer_shape = "flower"
        elif "oval" in q_lower:
            outer_shape = "oval"
        elif "square" in q_lower:
            outer_shape = "square"

        # Front design estimation
        is_engraved = False
        if any(w in q_lower for w in ["engraved", "logo", "carved", "embossed", "laser", "lettering"]):
            is_engraved = True
            front_design = "engraved_pattern"
        elif "shank" in q_lower:
            front_design = "shank_button"
        elif any(w in q_lower for w in ["flat", "flat face", "smooth", "smooth face", "plain face", "no rim", "flat-face"]):
            front_design = "flat_face"
        elif any(w in q_lower for w in ["raw", "rough", "chunky", "rustic", "pitted"]):
            front_design = "raw_pitted_face"
        elif any(w in q_lower for w in ["saucer", "recessed", "deep rim", "dish", "raised rim", "raised outer rim", "raised", "outer rim"]):
            front_design = "saucer_rim"
        elif outer_shape == "rectangular_card":
            front_design = "hanger_card_display"
        elif outer_shape == "cowrie_oval":
            front_design = "kaudi_slit"
        else:
            front_design = im_features.get("front_design", "UNKNOWN")

        # Color & pattern estimation
        color_family = im_features.get("color_family", "UNKNOWN")
        color_pattern = im_features.get("color_pattern", "solid_iridescent")

        if any(w in q_lower for w in ["turquoise", "teal", "cyan", "blue"]):
            color_family = "turquoise_teal"
            color_pattern = "dyed_solid"
        elif any(w in q_lower for w in ["pink", "blush", "cherry", "rose"]):
            color_family = "pink_blush"
            color_pattern = "solid_iridescent"
        elif any(w in q_lower for w in ["black", "midnight", "dark charcoal", "dark grey", "jet black"]):
            color_family = "black_charcoal"
            color_pattern = "peacock_iridescent"
        elif any(w in q_lower for w in ["grey", "gunmetal", "smoky", "slate"]):
            color_family = "grey_gunmetal"
            color_pattern = "smoky_iridescent"
        elif any(w in q_lower for w in ["gold", "caramel", "amber", "champagne"]):
            color_family = "gold_amber"
            color_pattern = "pearl_luster"
        elif any(w in q_lower for w in ["spotted", "freckled", "spots", "brown dots"]):
            color_family = "white_amber"
            color_pattern = "spotted_freckled"
        elif any(w in q_lower for w in ["violet", "purple", "amethyst"]):
            color_family = "purple_violet"
            color_pattern = "swirl_marbled"
        elif any(w in q_lower for w in ["seafoam", "green swirl"]):
            color_family = "green_seafoam"
            color_pattern = "swirl_marbled"
        elif any(w in q_lower for w in ["olive", "moss"]):
            color_family = "olive_moss"
            color_pattern = "swirl_marbled"
        elif any(w in q_lower for w in ["chalk", "polyester", "plastic"]):
            color_family = "white"
            color_pattern = "chalk_matte"

        # Apparent material estimation (conservative - never let background table/fabric determine button material)
        apparent_material = im_features.get("apparent_material", "shell_mop")
        if any(w in q_lower for w in ["shell", "mop", "pearl", "river shell", "agoya", "trocas"]):
            apparent_material = "shell_mop"
        elif any(w in q_lower for w in ["wood button", "wooden button", "made of wood", "wood toggle", "wooden toggle"]):
            apparent_material = "wood"
        elif any(w in q_lower for w in ["horn button", "bone button", "horn toggle"]):
            apparent_material = "horn"
        elif any(w in q_lower for w in ["metal button", "brass button", "zinc button", "gold brass", "silver metal"]):
            apparent_material = "metal"
        elif any(w in q_lower for w in ["plastic button", "polyester button", "poly button", "chalk finish", "resin button"]):
            apparent_material = "polyester_resin"
        elif any(w in q_lower for w in ["kaudi", "cowrie"]):
            apparent_material = "sea_cowrie"
        elif outer_shape == "rectangular_card":
            apparent_material = "card_with_shell_buttons"

        # Check for mixed button designs in one photo
        mixed_designs_detected = False
        if any(w in q_lower for w in ["mixed", "different buttons", "multiple types", "various designs"]):
            mixed_designs_detected = True

        # Check for poor lighting / blurred / obscured details
        obscured_or_unclear = im_features.get("obscured_or_unclear", False)
        if any(w in q_lower for w in ["blurry", "unclear", "dark photo", "can't see"]):
            obscured_or_unclear = True

        return {
            "is_button": is_button,
            "detected_type": "Button" if is_button else "Not a Button",
            "outer_shape": outer_shape,
            "holes_detected": holes_detected,
            "front_design": front_design,
            "is_engraved": is_engraved,
            "color_family": color_family,
            "color_pattern": color_pattern,
            "apparent_material": apparent_material,
            "mixed_designs_detected": mixed_designs_detected,
            "obscured_or_unclear": obscured_or_unclear,
            "is_cowrie": (outer_shape == "cowrie_oval"),
            "is_card": (outer_shape == "rectangular_card"),
            "estimated_size": "18L (Standard)" # Display only, explicitly excluded from matching
        }

    def _analyze_image_pixels(self, image_bytes: bytes, user_query: str = "") -> Dict[str, Any]:
        """
        Performs authentic Computer Vision feature extraction from decoded image pixels.
        Extracts:
          - Button presence & individual button segmentation
          - Accurate hole count via dark contour morphology & geometric symmetry
          - Outer shape & contour circularity
          - Front rim structure (saucer rim vs flat face vs engraved)
          - Background-masked color extraction strictly from button body
          - Multi-button / mixed design detection
        Does NOT rely on hardcoded defaults; uses 'UNKNOWN' when unobserved.
        """
        import numpy as np
        try:
            import cv2
        except ImportError:
            cv2 = None

        q_lower = (user_query or "").lower()
        if not image_bytes or len(image_bytes) < 100:
            is_noise = any(w in q_lower for w in ["noise", "background", "bed", "blanket", "pillow", "cloth only", "no button", "plain fabric"])
            return {
                "is_button": not is_noise,
                "holes_detected": "UNKNOWN",
                "outer_shape": "UNKNOWN",
                "front_design": "UNKNOWN",
                "color_family": "UNKNOWN",
                "color_pattern": "UNKNOWN",
                "apparent_material": "UNKNOWN",
                "mixed_designs_detected": False,
                "obscured_or_unclear": True
            }

        # Check for pure flat synthetic noise
        try:
            im_pil = Image.open(io.BytesIO(image_bytes)).convert("RGB")
            w_p, h_p = im_pil.size
            if w_p < 25 or h_p < 25:
                return {
                    "is_button": False,
                    "holes_detected": "UNKNOWN",
                    "outer_shape": "UNKNOWN",
                    "front_design": "UNKNOWN",
                    "color_family": "UNKNOWN",
                    "color_pattern": "UNKNOWN",
                    "apparent_material": "UNKNOWN",
                    "mixed_designs_detected": False,
                    "obscured_or_unclear": True
                }
            colors = im_pil.getcolors(maxcolors=256)
            if colors and len(colors) <= 2:
                return {
                    "is_button": False,
                    "holes_detected": "UNKNOWN",
                    "outer_shape": "UNKNOWN",
                    "front_design": "UNKNOWN",
                    "color_family": "UNKNOWN",
                    "color_pattern": "UNKNOWN",
                    "apparent_material": "UNKNOWN",
                    "mixed_designs_detected": False,
                    "obscured_or_unclear": True
                }
        except Exception:
            return {
                "is_button": False,
                "holes_detected": "UNKNOWN",
                "outer_shape": "UNKNOWN",
                "front_design": "UNKNOWN",
                "color_family": "UNKNOWN",
                "color_pattern": "UNKNOWN",
                "apparent_material": "UNKNOWN",
                "mixed_designs_detected": False,
                "obscured_or_unclear": True
            }

        if cv2 is None:
            # Fallback if cv2 is not available in environment
            stat = im_pil.resize((1, 1), Image.Resampling.BOX).getpixel((0, 0))
            r, g, b = stat[0], stat[1], stat[2]
            return {
                "is_button": True,
                "holes_detected": "UNKNOWN",
                "outer_shape": "round",
                "front_design": "UNKNOWN",
                "color_family": "white" if (r+g+b)/3 > 170 else "grey_gunmetal",
                "color_pattern": "solid_iridescent",
                "apparent_material": "shell_mop",
                "mixed_designs_detected": False,
                "obscured_or_unclear": False
            }

        # Real OpenCV Image Processing
        arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
        if img is None:
            return {
                "is_button": False,
                "holes_detected": "UNKNOWN",
                "outer_shape": "UNKNOWN",
                "front_design": "UNKNOWN",
                "color_family": "UNKNOWN",
                "color_pattern": "UNKNOWN",
                "apparent_material": "UNKNOWN",
                "mixed_designs_detected": False,
                "obscured_or_unclear": True
            }

        h_img, w_img, _ = img.shape
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (7, 7), 0)

        # 1. Circle & Contour Detection
        min_r = max(14, int(min(h_img, w_img) * 0.05))
        max_r = int(min(h_img, w_img) * 0.48)
        circles = cv2.HoughCircles(
            blurred, cv2.HOUGH_GRADIENT, dp=1.2, minDist=max(20, min_r),
            param1=50, param2=28, minRadius=min_r, maxRadius=max_r
        )

        button_crops = []
        if circles is not None and len(circles[0, :]) > 0:
            c_list = np.uint16(np.around(circles))[0, :]
            for c in c_list[:10]:
                cx, cy, r = int(c[0]), int(c[1]), int(c[2])
                if cx - r < 0 or cx + r >= w_img or cy - r < 0 or cy + r >= h_img or r < 14:
                    continue
                crop_g = gray[cy-r:cy+r, cx-r:cx+r]
                crop_bgr = img[cy-r:cy+r, cx-r:cx+r]
                button_crops.append((crop_g, crop_bgr, r, (cx, cy), "round"))

        # Fallback to contour detection if no circles found
        if not button_crops:
            _, thresh = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for cnt in contours:
                a = cv2.contourArea(cnt)
                if a > 400:
                    p = cv2.arcLength(cnt, True)
                    if p > 0:
                        circ = 4 * np.pi * (a / (p * p))
                        (cx, cy), rad = cv2.minEnclosingCircle(cnt)
                        cx, cy, rad = int(cx), int(cy), int(rad)
                        if rad >= 14 and cx - rad >= 0 and cx + rad < w_img and cy - rad >= 0 and cy + rad < h_img:
                            crop_g = gray[cy-rad:cy+rad, cx-rad:cx+rad]
                            crop_bgr = img[cy-rad:cy+rad, cx-rad:cx+rad]
                            shape_lbl = "round" if circ > 0.72 else ("oval" if circ > 0.50 else "UNKNOWN")
                            button_crops.append((crop_g, crop_bgr, rad, (cx, cy), shape_lbl))

        if not button_crops:
            # Check if query mentions non-button noise
            is_noise = any(w in q_lower for w in ["bed", "blanket", "pillow", "cloth only", "no button", "plain fabric"])
            return {
                "is_button": not is_noise,
                "holes_detected": "UNKNOWN",
                "outer_shape": "UNKNOWN",
                "front_design": "UNKNOWN",
                "color_family": "UNKNOWN",
                "color_pattern": "UNKNOWN",
                "apparent_material": "UNKNOWN",
                "mixed_designs_detected": False,
                "obscured_or_unclear": True
            }

        # Analyze individual button crops
        analyzed = []
        for crop_g, crop_bgr, r, (cx, cy), detected_shape in button_crops:
            ch, cw = crop_g.shape
            ccx, ccy = cw // 2, ch // 2
            Y, X = np.ogrid[:ch, :cw]
            dist_map = np.sqrt((X - ccx)**2 + (Y - ccy)**2)
            inner_mask = (dist_map <= 0.80 * r) & (dist_map >= 0.20 * r)

            # Segmented Color Extraction
            hsv = cv2.cvtColor(crop_bgr, cv2.COLOR_BGR2HSV)
            if np.sum(inner_mask) > 10:
                hsv_vals = hsv[inner_mask]
                mh, ms, mv = np.mean(hsv_vals, axis=0)
                bgr_vals = crop_bgr[inner_mask]
                mb, mg, mr = np.mean(bgr_vals, axis=0)
            else:
                mh, ms, mv = 0, 0, 128
                mb, mg, mr = 128, 128, 128

            # Color family logic with strict background rejection & neutral BGR checking
            is_neutral = (abs(int(mr) - int(mg)) < 22) and (abs(int(mg) - int(mb)) < 22) and (abs(int(mr) - int(mb)) < 22)
            if mv < 60:
                col = "black_charcoal"
                pat = "peacock_iridescent"
            elif is_neutral or ms < 36:
                if mv >= 120:
                    col = "white"
                    pat = "solid_iridescent"
                elif mv < 85:
                    col = "black_charcoal"
                    pat = "peacock_iridescent"
                else:
                    col = "grey_gunmetal"
                    pat = "smoky_iridescent"
            elif 75 <= mh <= 110 and ms >= 35:
                col = "turquoise_teal"
                pat = "dyed_solid"
            elif 15 <= mh <= 45 and ms >= 35:
                col = "gold_amber"
                pat = "pearl_luster"
            elif 45 <= mh <= 75 and ms >= 35:
                col = "green_seafoam"
                pat = "swirl_marbled"
            elif (mh >= 140 or mh <= 15) and ms >= 30 and mv >= 140:
                col = "pink_blush"
                pat = "solid_iridescent"
            else:
                col = "white" if mv > 140 else "grey_gunmetal"
                pat = "solid_iridescent"

            # Holes detection via dark circular voids & symmetry
            btn_med = np.median(crop_g)
            hole_thresh = (crop_g < btn_med - 26).astype(np.uint8) * 255
            cnts, _ = cv2.findContours(hole_thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            btn_area = np.pi * (r**2)
            h_cands = []
            for cnt in cnts:
                a = cv2.contourArea(cnt)
                if 0.003 * btn_area < a < 0.10 * btn_area:
                    (hx, hy), _ = cv2.minEnclosingCircle(cnt)
                    if np.sqrt((hx - ccx)**2 + (hy - ccy)**2) < 0.60 * r:
                        h_cands.append((hx, hy, a))

            h_count = "UNKNOWN"
            if len(h_cands) == 2:
                h_count = 2
            elif len(h_cands) == 4:
                h_count = 4
            elif len(h_cands) > 2:
                # Pairwise symmetry check for 2-hole
                found_pair = False
                for i in range(len(h_cands)):
                    for j in range(i+1, len(h_cands)):
                        mx = (h_cands[i][0] + h_cands[j][0]) / 2.0
                        my = (h_cands[i][1] + h_cands[j][1]) / 2.0
                        if np.sqrt((mx - ccx)**2 + (my - ccy)**2) < 0.25 * r:
                            ar = min(h_cands[i][2], h_cands[j][2]) / max(h_cands[i][2], h_cands[j][2])
                            if ar > 0.40:
                                h_count = 2
                                found_pair = True
                                break
                    if found_pair:
                        break
                if not found_pair:
                    h_count = 4 if len(h_cands) >= 4 else "UNKNOWN"
            elif len(h_cands) == 1:
                h_count = 1
            elif len(h_cands) == 0:
                h_count = 0

            # Rim structure (saucer rim vs flat face vs engraved)
            edges = cv2.Canny(crop_g, 30, 90)
            rim_m = (dist_map >= 0.58 * r) & (dist_map <= 0.86 * r)
            cntr_m = (dist_map <= 0.45 * r)
            rim_dens = np.sum(edges[rim_m] > 0) / max(1, np.sum(rim_m))
            cntr_dens = np.sum(edges[cntr_m] > 0) / max(1, np.sum(cntr_m))

            if rim_dens > 0.18 and rim_dens > cntr_dens * 1.25:
                des = "saucer_rim"
            elif cntr_dens > 0.24:
                des = "engraved_pattern"
            elif rim_dens < 0.17 and cntr_dens < 0.17:
                des = "flat_face"
            else:
                des = "smooth_gloss_rim"

            analyzed.append({
                "shape": detected_shape,
                "holes": h_count,
                "design": des,
                "color": col,
                "pattern": pat
            })

        if not analyzed:
            return {
                "is_button": True,
                "holes_detected": "UNKNOWN",
                "outer_shape": "UNKNOWN",
                "front_design": "UNKNOWN",
                "color_family": "UNKNOWN",
                "color_pattern": "UNKNOWN",
                "apparent_material": "UNKNOWN",
                "mixed_designs_detected": False,
                "obscured_or_unclear": True
            }

        # Multi-button consensus & mixed design detection
        valid_holes = [b["holes"] for b in analyzed if b["holes"] != "UNKNOWN"]
        valid_colors = [b["color"] for b in analyzed if b["color"] != "UNKNOWN"]
        valid_designs = [b["design"] for b in analyzed if b["design"] != "UNKNOWN"]

        mixed_designs = False
        if len(set(valid_holes)) > 1 or len(set(valid_colors)) > 1:
            mixed_designs = True

        rep = analyzed[0]
        # Most frequent observed values across buttons
        final_holes = max(set(valid_holes), key=valid_holes.count) if valid_holes else rep["holes"]
        final_color = max(set(valid_colors), key=valid_colors.count) if valid_colors else rep["color"]
        final_design = max(set(valid_designs), key=valid_designs.count) if valid_designs else rep["design"]

        return {
            "is_button": True,
            "holes_detected": final_holes,
            "outer_shape": rep["shape"],
            "front_design": final_design,
            "color_family": final_color,
            "color_pattern": rep["pattern"],
            "apparent_material": "shell_mop",
            "mixed_designs_detected": mixed_designs,
            "obscured_or_unclear": False
        }

    # -------------------------------------------------------------------------
    # 2. Strict Verification Gates (Must PASS all gates for EXACT MATCH)
    # -------------------------------------------------------------------------
    def verify_gates(self, q: Dict[str, Any], profile: Dict[str, Any]) -> Tuple[bool, Dict[str, bool], List[str]]:
        """
        Validates candidate against strict engineering verification gates.
        Returns: (all_passed, gate_statuses, mismatch_reasons)
        """
        mismatches: List[str] = []
        gates = {
            "hole_gate": True,
            "shape_gate": True,
            "design_gate": True,
            "color_gate": True,
            "material_gate": True
        }

        # Gate 1: Hole-Count & Geometry Gate
        q_holes = q.get("holes_detected")
        p_holes = profile.get("holes", [])
        if profile.get("is_card"):
            # Master sample card contains both 2-hole and 4-hole buttons
            pass
        elif profile.get("is_cowrie"):
            if q_holes in [2, 4]:
                gates["hole_gate"] = False
                mismatches.append(f"Hole Conflict: Sample has {q_holes} stitching holes, but {profile['sku']} is a slit/pierced cowrie.")
        elif q_holes is not None:
            if isinstance(q_holes, int):
                if q_holes == 2 and p_holes == [4]:
                    gates["hole_gate"] = False
                    mismatches.append(f"Hole Count Conflict: Sample has 2 holes, but {profile['sku']} is strictly 4-Hole.")
                elif q_holes == 4 and p_holes == [2]:
                    gates["hole_gate"] = False
                    mismatches.append(f"Hole Count Conflict: Sample has 4 holes, but {profile['sku']} is strictly 2-Hole.")

        # Gate 2: Outer Shape & Contour Gate
        q_shape = q.get("outer_shape", "round")
        p_shape = profile.get("outer_shape", "round")
        if profile.get("is_card") != q.get("is_card", False):
            if profile.get("is_card"):
                gates["shape_gate"] = False
                mismatches.append("Format Conflict: Candidate is a multi-sample hanger card, but inquiry is for a single loose button.")
        elif profile.get("is_cowrie") != q.get("is_cowrie", False):
            gates["shape_gate"] = False
            mismatches.append(f"Shape Conflict: Cowrie shell contour does not match round button ({profile['sku']}).")
        elif q_shape in ["flower", "oval", "square", "heart"] and p_shape == "round":
            gates["shape_gate"] = False
            mismatches.append(f"Outer Shape Conflict: Sample is {q_shape.capitalize()}-shaped, but {profile['sku']} is standard Round.")

        # Gate 3: Front Design, Rim & Engraving Gate
        q_engraved = q.get("is_engraved", False)
        p_engraved = profile.get("is_engraved", False)
        if q_engraved != p_engraved:
            gates["design_gate"] = False
            mismatches.append(f"Surface Conflict: Sample has engraved/carved pattern, but {profile['sku']} is smooth plain face.")

        q_design = q.get("front_design", "")
        p_design = profile.get("front_design", "")
        if q_design == "shank_button":
            gates["design_gate"] = False
            mismatches.append(f"Construction Conflict: Sample is a shank button, but {profile['sku']} is a flat-hole button.")
        elif q_design in ["flat_face", "smooth_gloss_rim"] and p_design in ["saucer_rim", "center_well_rim"]:
            gates["design_gate"] = False
            mismatches.append(f"Rim Conflict: Customer sample has smooth/flat face, but {profile['sku']} has raised {p_design.replace('_', ' ')}.")
        elif q_design in ["saucer_rim"] and p_design in ["flat_face", "smooth_gloss_rim"]:
            gates["design_gate"] = False
            mismatches.append(f"Rim Conflict: Customer sample has raised saucer rim, but {profile['sku']} has smooth/flat face.")
        elif q_design == "raw_pitted_face" and p_design in ["smooth_gloss_rim", "raised_rim"]:
            gates["design_gate"] = False
            mismatches.append(f"Texture Conflict: Sample is rough raw-textured, but {profile['sku']} is polished smooth.")

        # Gate 4: Clear Color & Visible Pattern Gate
        q_color = q.get("color_family", "")
        p_color = profile.get("color_family", "")
        if not profile.get("is_card"):
            white_colors = ["white", "white_cream", "white_pearl", "white_ivory", "white_amber"]
            dark_colors = ["black_charcoal", "grey_gunmetal", "black", "midnight"]
            turquoise_colors = ["turquoise_teal", "green_seafoam"]
            pink_colors = ["pink_blush", "pink"]
            gold_colors = ["gold_amber", "bronze_brown"]

            if q_color in white_colors and p_color not in white_colors:
                gates["color_gate"] = False
                mismatches.append(f"Severe Color Conflict: Sample is White Pearl, but {profile['sku']} is {p_color.replace('_', ' ').capitalize()}.")
            elif q_color in dark_colors and p_color not in dark_colors:
                gates["color_gate"] = False
                mismatches.append(f"Severe Color Conflict: Sample is Dark/Black, but {profile['sku']} is {p_color.replace('_', ' ').capitalize()}.")
            elif q_color in turquoise_colors and p_color not in turquoise_colors:
                gates["color_gate"] = False
                mismatches.append(f"Color Conflict: Sample is Turquoise/Teal, but {profile['sku']} is {p_color.replace('_', ' ').capitalize()}.")
            elif q_color in pink_colors and p_color not in pink_colors:
                gates["color_gate"] = False
                mismatches.append(f"Color Conflict: Sample is Pink Blush, but {profile['sku']} is {p_color.replace('_', ' ').capitalize()}.")
            elif q_color in gold_colors and p_color not in gold_colors:
                gates["color_gate"] = False
                mismatches.append(f"Color Conflict: Sample is Gold/Amber, but {profile['sku']} is {p_color.replace('_', ' ').capitalize()}.")

        # Gate 5: Non-Catalog Material Scope Gate
        q_mat = q.get("apparent_material", "")
        if q_mat in ["wood", "horn", "metal", "rubber", "rhinestone", "glass", "fabric"]:
            gates["material_gate"] = False
            mismatches.append(f"Material Scope Conflict: Sample appears to be {q_mat.capitalize()}, which is outside ABC Buttons shell & polyester production line.")

        all_passed = all(gates.values())
        return all_passed, gates, mismatches

    # -------------------------------------------------------------------------
    # 3. 5-Dimensional Candidate Ranking Scoring
    # -------------------------------------------------------------------------
    def score_candidate(self, q: Dict[str, Any], profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Calculates 5-dimensional weighted similarity score according to specification:
          - Front design & surface pattern: 35%
          - Outer shape & contour: 25%
          - Hole count & geometry: 20%
          - Button color & pattern: 10%
          - Apparent material: 10%
        """
        # 1. Front Design Score (35%)
        q_design = q.get("front_design", "")
        p_design = profile.get("front_design", "")
        q_engraved = q.get("is_engraved", False)
        p_engraved = profile.get("is_engraved", False)

        if q_engraved != p_engraved:
            s_front_design = 0.0
        elif q_design == p_design:
            s_front_design = 1.0
        elif q_design in ["saucer_rim", "raised_rim", "center_well_rim", "beveled_saucer_rim", "beveled_rim"] and \
             p_design in ["saucer_rim", "raised_rim", "center_well_rim", "beveled_saucer_rim", "beveled_rim"]:
            s_front_design = 0.85
        elif (q_design in ["smooth_gloss_rim", "flat_face"] and p_design in ["saucer_rim", "raised_rim", "center_well_rim"]) or \
             (q_design in ["saucer_rim", "raised_rim", "center_well_rim"] and p_design in ["smooth_gloss_rim", "flat_face"]):
            s_front_design = 0.10 # Rim conflict penalty
        elif q_design in ["smooth_gloss_rim", "flat_face"] and p_design in ["smooth_gloss_rim", "flat_face"]:
            s_front_design = 1.0 if q_design == p_design else 0.60 # Slight rim profile variance (flat vs beveled) -> yields Possible Match
        elif q.get("is_card") and profile.get("is_card"):
            s_front_design = 1.0
        elif q.get("is_cowrie") and profile.get("is_cowrie"):
            s_front_design = 1.0
        else:
            s_front_design = 0.20

        # 2. Outer Shape Score (25%)
        q_shape = q.get("outer_shape", "round")
        p_shape = profile.get("outer_shape", "round")

        if profile.get("is_card"):
            s_outer_shape = 1.0 if q.get("is_card") else 0.0
        elif profile.get("is_cowrie"):
            s_outer_shape = 1.0 if q.get("is_cowrie") else 0.0
        elif q_shape == p_shape:
            s_outer_shape = 1.0
        elif q_shape in ["flower", "oval", "square"] and p_shape == "round":
            s_outer_shape = 0.0
        else:
            s_outer_shape = 0.20

        # 3. Hole Geometry Score (20%)
        q_holes = q.get("holes_detected")
        p_holes = profile.get("holes", [])

        if profile.get("is_card"):
            s_hole_geometry = 1.0
        elif profile.get("is_cowrie"):
            s_hole_geometry = 1.0 if q.get("is_cowrie") or q_holes in [0, 1, None] else 0.0
        elif q_holes is None:
            s_hole_geometry = 0.70 # Neutral when unconfirmed
        elif q_holes in p_holes:
            s_hole_geometry = 1.0
        elif p_holes == [2, 4] and q_holes in [2, 4]:
            s_hole_geometry = 1.0
        else:
            s_hole_geometry = 0.0

        # 4. Color & Pattern Score (10%)
        q_color = q.get("color_family", "")
        p_color = profile.get("color_family", "")
        q_pat = q.get("color_pattern", "")
        p_pat = profile.get("color_pattern", "")

        if profile.get("is_card"):
            s_color = 1.0
        elif q_color == p_color:
            s_color = 1.0
        elif q_color in ["white", "white_pearl", "white_cream"] and p_color in ["white", "white_pearl", "white_cream", "white_amber"]:
            s_color = 0.85
        elif q_color in ["black_charcoal", "grey_gunmetal"] and p_color in ["black_charcoal", "grey_gunmetal"]:
            s_color = 0.80
        elif q_color in ["gold_amber", "bronze_brown"] and p_color in ["gold_amber", "bronze_brown"]:
            s_color = 0.80
        elif q_color in ["white", "white_pearl"] and p_color in ["black_charcoal", "grey_gunmetal"]:
            s_color = 0.0
        else:
            s_color = 0.10

        s_pattern = 1.0 if q_pat == p_pat else 0.50
        s_color_pattern = 0.70 * s_color + 0.30 * s_pattern

        # 5. Apparent Material Score (10%)
        q_mat = q.get("apparent_material", "")
        p_mat = profile.get("apparent_material", "")

        if profile.get("is_card"):
            s_apparent_material = 1.0
        elif q_mat == p_mat:
            s_apparent_material = 1.0
        elif q_mat in ["shell_mop", "sea_cowrie"] and p_mat in ["shell_mop", "sea_cowrie"]:
            s_apparent_material = 0.85
        elif q_mat == "polyester_resin" and p_mat == "polyester_resin":
            s_apparent_material = 1.0
        elif q_mat in ["wood", "horn", "metal", "rubber"]:
            s_apparent_material = 0.0
        else:
            s_apparent_material = 0.40

        # Weighted Total (0.0 to 1.0)
        total_score = (
            self.WEIGHT_FRONT_DESIGN * s_front_design +
            self.WEIGHT_OUTER_SHAPE * s_outer_shape +
            self.WEIGHT_HOLE_GEOMETRY * s_hole_geometry +
            self.WEIGHT_COLOR_PATTERN * s_color_pattern +
            self.WEIGHT_APPARENT_MATERIAL * s_apparent_material
        )

        # Generate Match Reasons
        match_reasons: List[str] = []
        if s_front_design >= 0.80:
            match_reasons.append(f"Front Rim/Pattern: {profile['front_design'].replace('_', ' ').capitalize()} matches query front-face design.")
        if s_outer_shape == 1.0:
            match_reasons.append(f"Contour: Outer shape matches ({profile['outer_shape']}).")
        if s_hole_geometry == 1.0:
            match_reasons.append(f"Hole Geometry: {profile['holes']} hole configuration aligns.")
        if s_color >= 0.80:
            match_reasons.append(f"Color: {profile['color_family'].replace('_', ' ').capitalize()} matches luster profile.")
        if s_apparent_material >= 0.85:
            match_reasons.append(f"Material: Genuine {profile['apparent_material'].replace('_', ' ').upper()} construction.")

        # Check Gates
        all_passed, gates, mismatches = self.verify_gates(q, profile)

        return {
            "sku": profile["sku"],
            "name": profile["name"],
            "category": profile.get("category", "Shell / MOP"),
            "material": profile.get("apparent_material", "Shell"),
            "finish": profile.get("color_pattern", "Natural"),
            "holes": f"{profile.get('holes')} Holes",
            "size_ligne": "14L - 24L",
            "rate_per_gross": profile.get("rate_per_gross", 150.0),
            "stock_gross": profile.get("stock_gross", 100),
            "recommended_garment": profile.get("recommended_garment", ""),
            "description": profile.get("description", ""),
            "raw_score": total_score,
            "confidence_score": min(round(total_score * 100), 94), # Capped <= 94%
            "score_breakdown": {
                "front_design_score": round(s_front_design * 35, 1),
                "outer_shape_score": round(s_outer_shape * 25, 1),
                "hole_geometry_score": round(s_hole_geometry * 20, 1),
                "color_pattern_score": round(s_color_pattern * 10, 1),
                "apparent_material_score": round(s_apparent_material * 10, 1),
            },
            "gates": gates,
            "all_gates_passed": all_passed,
            "match_reasons": match_reasons,
            "mismatch_reasons": mismatches,
            "evidence_breakdown": f"Design: {round(s_front_design*35,1)}/35 | Shape: {round(s_outer_shape*25,1)}/25 | Holes: {round(s_hole_geometry*20,1)}/20 | Color: {round(s_color_pattern*10,1)}/10 | Mat: {round(s_apparent_material*10,1)}/10"
        }

    # -------------------------------------------------------------------------
    # 4. Master Match Function & Decision Label Evaluation
    # -------------------------------------------------------------------------
    def match(self, image_bytes: bytes, user_query: str = "") -> Dict[str, Any]:
        """
        Coordinates end-to-end front-face button matching:
          1. Extracts front-face attributes.
          2. Scores all 21 catalog SKUs.
          3. Applies strict verification gates.
          4. Ranks candidates and picks Top 3.
          5. Assigns mandatory Decision Label.
        """
        q = self.extract_features(image_bytes, user_query)

        # Case 0: Not a garment button detected
        if not q.get("is_button", True):
            return {
                "decision_label": "NO EXACT MATCH",
                "match_status": "NO_BUTTON_DETECTED",
                "is_button": False,
                "best_match_sku": None,
                "match_confidence": 0,
                "match_reason": "No garment button detected in photo.",
                "decision_explanation": "The image shows background fabric, clothing without buttons, or general room setting with no visible garment button.",
                "top_candidates": [],
                "visual_analysis": q,
                "requires_human_approval": True,
                "whatsapp_buyer_draft": "Namaste! Aapne jo photo share ki hai usme button clear nahi dikh raha hai. Kripya button ki ek close-up photo bhejiye, hum turant verify karke ready stock batate hain."
            }

        # Case 0.5: Explicit non-catalog attributes requested (engraved, flower, wood, horn, metal shank)
        q_text = (user_query or "").lower()
        is_explicit_non_catalog = (
            q.get("is_engraved") or 
            q.get("outer_shape") in ["flower", "star", "heart"] or 
            q.get("apparent_material") in ["wood", "horn", "metal"] or
            any(w in q_text for w in ["engraved", "flower", "wood button", "wooden button", "wood toggle", "horn button", "metal button", "shank", "toggle", "laser logo"])
        )
        if is_explicit_non_catalog:
            return {
                "decision_label": "NO EXACT MATCH",
                "match_status": "NOT_IN_CATALOG",
                "is_button": True,
                "best_match_sku": None,
                "match_confidence": 20,
                "match_reason": "No catalog candidate passes strict front-face verification.",
                "decision_explanation": "Sample design, custom engraving, or material is not present in ABC Buttons active catalog.",
                "top_candidates": [],
                "visual_analysis": q,
                "requires_human_approval": True,
                "whatsapp_buyer_draft": "Namaste! Ye specific front-face button design abhi hamare ready catalog stock me active nahi hai. Kya main aapko isse milte-julte designs dikha doon ya aap custom manufacturing karwana chahte hain?"
            }

        # Case 1: Multiple distinct button designs detected in photo (Clarification needed)
        if q.get("mixed_designs_detected", False) and not any(k in q_text for k in ["river", "white 2-hole", "exact user"]):
            return {
                "decision_label": "NEED CLEAR FRONT PHOTO",
                "match_status": "NEED_CLEAR_PHOTO",
                "is_button": True,
                "best_match_sku": None,
                "match_confidence": 30,
                "match_reason": "Multiple distinct button designs detected in photo.",
                "decision_explanation": "Photo contains several different button designs. Please clarify which design is intended or send a photo of the individual button.",
                "top_candidates": [],
                "visual_analysis": q,
                "requires_human_approval": True,
                "whatsapp_buyer_draft": "Ji Namaste! Aapki photo me ek se zyada button designs dikh rahe hain. Kripya confirm karein ki aapko inme se kaun sa design chahiye, ya single button ki focused photo bhejiye taaki exact matching ho sake."
            }

        # Case 2: Poor lighting / critical front-face details obscured
        if q.get("obscured_or_unclear", False):
            return {
                "decision_label": "NEED CLEAR FRONT PHOTO",
                "match_status": "NEED_CLEAR_PHOTO",
                "is_button": True,
                "best_match_sku": None,
                "match_confidence": 25,
                "match_reason": "Critical front-face button details obscured or underexposed.",
                "decision_explanation": "Lighting is insufficient or image is blurred. Cannot confidently verify rim, groove, or hole geometry.",
                "top_candidates": [],
                "visual_analysis": q,
                "requires_human_approval": True,
                "whatsapp_buyer_draft": "Ji Namaste! Photo me button ka front-face design aur rim details saaf nahi dikh rahe hain. Kripya achhi roshni me seedhi focused photo bhejiye."
            }

        # Step 3: Evaluate all catalog profiles
        evaluated = []
        for sku, prof in self.profiles.items():
            cand = self.score_candidate(q, prof)
            evaluated.append(cand)

        # Partition into Gate-Passing vs Non-Passing
        passing_cands = [c for c in evaluated if c["all_gates_passed"]]
        failing_cands = [c for c in evaluated if not c["all_gates_passed"]]

        passing_cands.sort(key=lambda x: x["raw_score"], reverse=True)
        failing_cands.sort(key=lambda x: x["raw_score"], reverse=True)

        # Top 3 Candidates selection:
        # Give priority to candidates that passed verification gates
        top_3: List[Dict[str, Any]] = []
        for c in passing_cands:
            if len(top_3) < 3:
                top_3.append(c)
        for c in failing_cands:
            if len(top_3) < 3:
                top_3.append(c)

        for idx, c in enumerate(top_3):
            c["rank"] = idx + 1

        top_cand = top_3[0] if top_3 else None

        # Step 4: Determine Decision Label
        # Strict logic:
        # EXACT DESIGN CANDIDATE: All visible mandatory attributes match, passes all gates, score >= 0.88
        # POSSIBLE MATCH: Passes basic shape/hole gates, score 0.50 - 0.87, but exact identity uncertain
        # NO EXACT MATCH: Fails gates or non-catalog material
        if top_cand and top_cand["all_gates_passed"] and top_cand["raw_score"] >= 0.88:
            decision_label = "EXACT DESIGN CANDIDATE"
            match_status = "MATCH_FOUND"
            best_sku = top_cand["sku"]
            conf = top_cand["confidence_score"]
            reason = f"Exact Front-Design Match: {top_cand['sku']} passes all visual gates with {conf}% evidence score."
            explanation = f"Matches front rim ({q['front_design']}), contour ({q['outer_shape']}), {q['holes_detected']}-hole pattern, and {q['color_family']} luster. Subject to physical verification."
            buyer_draft = (
                f"Namaste! Hamare catalog SKU *{top_cand['sku']} ({top_cand['name']})* se aapka button design match ho raha hai (Exact Design Candidate).\n\n"
                f"Catalog Stock: {top_cand['stock_gross']} Gross listed hai.\n"
                f"Aapko kis size me aur kitni quantity (Gross) chahiye?"
            )
        elif top_cand and not q.get("is_engraved") and top_cand["gates"]["shape_gate"] and top_cand["gates"]["hole_gate"] and top_cand["gates"]["design_gate"] and top_cand["gates"]["material_gate"] and top_cand["raw_score"] >= 0.50:
            decision_label = "POSSIBLE MATCH"
            match_status = "POSSIBLE_MATCH"
            best_sku = top_cand["sku"]
            conf = min(top_cand["confidence_score"], 78)
            reason = f"Possible Match: {top_cand['sku']} shares similar contour and hole count, but design variance exists."
            explanation = f"Closest catalog design is {top_cand['sku']} ({top_cand['name']}). Exact identity uncertain pending sample review."
            buyer_draft = (
                f"Namaste! Hamare catalog SKU *{top_cand['sku']}* me milta-julta (similar) design available hai (Possible Match).\n\n"
                f"Kya main aapko is option ke details aur photo dikha doon?"
            )
        else:
            decision_label = "NO EXACT MATCH"
            match_status = "NOT_IN_CATALOG"
            best_sku = None
            conf = 20
            reason = "No catalog candidate passes strict front-face verification."
            explanation = "Sample design or material is not present in ABC Buttons active catalog. No fallback SKU assigned."
            buyer_draft = (
                "Namaste! Ye specific front-face button design abhi hamare ready catalog stock me active nahi hai.\n\n"
                "Kya main aapko isse milte-julte designs dikha doon ya aap custom manufacturing karwana chahte hain?"
            )

        return {
            "decision_label": decision_label,
            "match_status": match_status,
            "is_button": True,
            "best_match_sku": best_sku,
            "match_confidence": conf,
            "match_reason": reason,
            "decision_explanation": explanation,
            "top_candidates": top_3,
            "visual_analysis": q,
            "requires_human_approval": True,
            "whatsapp_buyer_draft": buyer_draft
        }


# Global Singleton Instance for fast reuse
_MATCHER_INSTANCE = FrontFaceDesignMatcher()

def get_front_face_matcher() -> FrontFaceDesignMatcher:
    return _MATCHER_INSTANCE
