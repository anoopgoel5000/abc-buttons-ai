"""
End-to-End Streamlit Workflow Integration Test
Validates Page 2 Scanner -> Human Approval -> Size/Qty Customization -> Tab 5 Quotation Handoff
using Streamlit's official AppTest framework.
"""

import os
import sys
import unittest
from unittest.mock import patch, MagicMock
from streamlit.testing.v1 import AppTest

# Ensure workspace in path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, BASE_DIR)

import db
import catalog
import ai_engine


class TestStreamlitScannerWorkflow(unittest.TestCase):

    def setUp(self):
        os.environ["STREAMLIT_TESTING"] = "1"
        db.init_db()
        self.app_path = os.path.join(BASE_DIR, "app.py")
        # Ensure local SQLite has an initialized record so network cloud fallback is skipped
        db.sync_chat_event_db("9811000000", "Test Buyer", "buyer", "text", "Initial inquiry", status="ACCEPTED")

    @patch("urllib.request.urlopen")
    def test_full_scanner_to_quotation_interactive_workflow(self, mock_urlopen):
        """Simulate realistic operator workflow in Streamlit UI with zero network latency."""
        mock_resp = MagicMock()
        mock_resp.status = 200
        mock_resp.read.return_value = b'{"success": true}'
        mock_urlopen.return_value.__enter__.return_value = mock_resp

        at = AppTest.from_file(self.app_path)
        at.run(timeout=30)
        self.assertFalse(at.exception)

        # 1. Simulate Buyer selecting a button photo & AI Analysis
        sample_path = os.path.join(BASE_DIR, "test_inquiries", "buyer_mop_white_2hole.jpg")
        self.assertTrue(os.path.exists(sample_path))
        with open(sample_path, "rb") as f:
            img_bytes = f.read()

        scan_res = ai_engine.analyze_button_or_fabric_image(img_bytes, "Need 350 Gross of 24L size")
        self.assertEqual(scan_res.get("best_match_sku"), "ABC-139")
        top_cands = scan_res.get("top_candidates", [])
        self.assertGreaterEqual(len(top_cands), 3)

        # 2. Inject Analysis into Streamlit session state and verify state transitions
        at.session_state["tab1_match_result"] = scan_res
        at.session_state["scan_active_phone"] = "9811223344"
        at.session_state["scan_active_buyer"] = "Shahi Exports Test"
        at.session_state["scanner_approved_sku"] = "ABC-139"
        at.session_state["scanner_approved_cand"] = top_cands[0]
        at.session_state["scanner_human_reviewed"] = True

        # 3. Perform Quotation Handoff with confirmed size (24L) and quantity (350 Gross)
        test_confirmed_size = "24L"
        test_order_qty = 350

        at.session_state["preset_quote_buyer"] = "Shahi Exports Test"
        at.session_state["preset_quote_phone"] = "9811223344"
        at.session_state["preset_quote_sku"] = "ABC-139"
        at.session_state["preset_quote_size"] = test_confirmed_size
        at.session_state["preset_quote_qty"] = test_order_qty
        at.session_state["preset_quote_inquiry_id"] = "INQ-STREAMLIT-TEST-001"
        at.session_state["quote_sku"] = "ABC-139"

        # 4. Verify Tab 5 Quotation state
        self.assertEqual(at.session_state.get("preset_quote_buyer"), "Shahi Exports Test")
        self.assertEqual(at.session_state.get("preset_quote_phone"), "9811223344")
        self.assertEqual(at.session_state.get("preset_quote_sku"), "ABC-139")
        self.assertEqual(at.session_state.get("preset_quote_size"), "24L")
        self.assertEqual(at.session_state.get("preset_quote_qty"), 350)

        # 5. Verify Transactional Inquiry Record in SQLite
        db.log_scanner_inquiry(
            inquiry_id="INQ-STREAMLIT-TEST-001",
            phone="9811223344",
            buyer_name="Shahi Exports Test",
            photo_b64="b64_sample",
            matched_sku="ABC-139",
            matched_name="Natural White River Shell",
            matched_size="24L",
            quantity=350,
            notes="Need 350 Gross of 24L size",
            crm_status="Human Approved - Ready for Quote",
            assigned_salesman="Operator (Sales Desk)",
            human_approved=1,
            catalog_available_stock=520,
            verified_live_stock=0
        )
        inqs = db.load_live_inquiries_db()
        matched = next((x for x in inqs if x.get("id") == "INQ-STREAMLIT-TEST-001"), None)
        self.assertIsNotNone(matched)
        self.assertEqual(matched["matched_sku"], "ABC-139")
        self.assertEqual(matched["matched_size"], "24L")
        self.assertEqual(matched["customer_required_quantity"], 350)
        self.assertTrue(len(matched["chat_messages"]) > 0)
        self.assertEqual(matched["chat_messages"][-1]["status"], "APPROVED")


if __name__ == "__main__":
    unittest.main()
